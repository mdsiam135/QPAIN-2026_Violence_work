
from sklearn import metrics
import os.path
import torch

#CHANGE 1:
# def getResult(y_test, y_pred):

#     if torch.is_tensor(y_test) and torch.is_tensor(y_pred):
#         y_test, y_pred = cudaTocpu(y_test, y_pred)
    
#     report = metrics.classification_report(y_test, y_pred, output_dict=True)
#     true = report['1']
#     fake = report['0']

#     overall = {"Accuracy": metrics.accuracy_score(y_test, y_pred), "recall": metrics.recall_score(y_test, y_pred),
#                "f1-score": metrics.f1_score(y_test, y_pred), "precision": metrics.precision_score(y_test, y_pred) }
    
#     overallmacro = {"Accuracy": metrics.accuracy_score(y_test, y_pred), "recall": metrics.recall_score(y_test, y_pred, average='macro'),
#                "f1-score": metrics.f1_score(y_test, y_pred, average='macro'), "precision": metrics.precision_score(y_test, y_pred, average='macro') }

#     return true, fake, overall, overallmicro

def getResult(y_test, y_pred):

    if torch.is_tensor(y_test) and torch.is_tensor(y_pred):
        y_test, y_pred = cudaTocpu(y_test, y_pred)
    
    report = metrics.classification_report(y_test, y_pred, output_dict=True)
    class0 = report['0']  # Non-Violence
    class1 = report['1']  # Passive Violence
    class2 = report['2']  # Active Violence

    accuracy = metrics.accuracy_score(y_test, y_pred)
    overall_weighted = {"precision": report['weighted avg']['precision'],
                        "recall": report['weighted avg']['recall'],
                        "f1-score": report['weighted avg']['f1-score'],
                        "Accuracy": accuracy}
    
    overall_macro = {"precision": report['macro avg']['precision'],
                     "recall": report['macro avg']['recall'],
                     "f1-score": report['macro avg']['f1-score'],
                     "Accuracy": accuracy}

    return class0, class1, class2, overall_weighted, overall_macro

# CHANGE 1: END

# CHANGE 2:
# def printResult(experiment, overall, fake):
#     experiment = experiment.ljust(14)
#     res = "{}     {:.2f}         {:.2f}        {:.2f}      #  {:.2f}         {:.2f}         {:.2f}".format(experiment,overall['precision'],overall['recall'],overall['f1-score'],fake['precision'],fake['recall'],fake['f1-score'])
#     return res

def printResult(experiment, overall, class0, class1, class2):
    experiment = experiment.ljust(14)
    res = "{}     {:.2f}         {:.2f}        {:.2f}      #  {:.2f}         {:.2f}         {:.2f}      #  {:.2f}         {:.2f}         {:.2f}      #  {:.2f}         {:.2f}         {:.2f}".format(
        experiment,
        overall['precision'], overall['recall'], overall['f1-score'],
        class0['precision'], class0['recall'], class0['f1-score'],
        class1['precision'], class1['recall'], class1['f1-score'],
        class2['precision'], class2['recall'], class2['f1-score']
    )
    return res
# CHANGE 2: END

# CHANGE 3:
# def getReport(y_test,y_pred):

#     if torch.is_tensor(y_test) and torch.is_tensor(y_pred):
#         y_test, y_pred = cudaTocpu(y_test, y_pred)
#     print("Accuracy:", metrics.accuracy_score(y_test, y_pred))
#     print("Precision:", metrics.precision_score(y_test, y_pred))
#     print("Recall:", metrics.recall_score(y_test, y_pred))
#     print("F1-Score:", metrics.f1_score(y_test, y_pred))
#     print("Confusion Matrix:", metrics.confusion_matrix(y_test, y_pred))
#     print(metrics.classification_report(y_test, y_pred))

def getReport(y_test,y_pred):

    if torch.is_tensor(y_test) and torch.is_tensor(y_pred):
        y_test, y_pred = cudaTocpu(y_test, y_pred)
    print("Accuracy:", metrics.accuracy_score(y_test, y_pred))
    print("Macro Precision:", metrics.precision_score(y_test, y_pred, average='macro'))
    print("Macro Recall:", metrics.recall_score(y_test, y_pred, average='macro'))
    print("Macro F1-Score:", metrics.f1_score(y_test, y_pred, average='macro'))
    print("Confusion Matrix:\n", metrics.confusion_matrix(y_test, y_pred))
    print(metrics.classification_report(y_test, y_pred))
# CHANGE 3: END

# CHANGE 4:
# def saveResults(path,res):
#     if os.path.isdir('./results') == False:
#         os.mkdir('results')
#     path = 'results/'+path
#     if os.path.exists('./'+path)==False:
#         with open(path, 'w', encoding="utf8") as file:
#             file.write("                                Overall               #               Fake                \n")
#             file.write("                   precision    recall      f1-score  #  precision    recall      f1-score\n")
#             file.write(res+"\n")
#     else:
#         with open(path, 'a', encoding="utf8") as file:
#             file.write(res+"\n")

def saveResults(path,res):
    if os.path.isdir('./results') == False:
        os.mkdir('results')
    path = 'results/'+path
    if os.path.exists('./'+path)==False:
        with open(path, 'w', encoding="utf8") as file:
            file.write("                                Overall               #            Non-Violence           #          Passive Violence         #          Active Violence          \n")
            file.write("                   precision    recall      f1-score  #  precision    recall      f1-score  #  precision    recall      f1-score  #  precision    recall      f1-score\n")
            file.write(res+"\n")
    else:
        with open(path, 'a', encoding="utf8") as file:
            file.write(res+"\n")
# CHANGE 4: END

def cudaTocpu(y_test,y_pred):
    y_test = [ y.cpu() if y.is_cuda else y for y in y_test ]
    y_pred = [ y.cpu() if y.is_cuda else y for y in y_pred ]

    return y_test, y_pred
